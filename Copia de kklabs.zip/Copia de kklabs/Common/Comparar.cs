﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Common
{
    public class Comparar
    {
        ArrayList Titulo = new ArrayList();
        ArrayList Clicks = new ArrayList();
        ArrayList Titulo2 = new ArrayList();
        ArrayList Clicks2 = new ArrayList();

        public ArrayList Titulo1 { get => Titulo; set => Titulo = value; }
        public ArrayList Clicks1 { get => Clicks; set => Clicks = value; }
        public ArrayList Titulo21 { get => Titulo2; set => Titulo2 = value; }
        public ArrayList Clicks21 { get => Clicks2; set => Clicks2 = value; }
    }
}
