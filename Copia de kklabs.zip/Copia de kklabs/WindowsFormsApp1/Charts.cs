﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Domain;
using LiveCharts;
using LiveCharts.Wpf;
using Common;



namespace Presentation
{
    public partial class Charts : Form
    {

        CD_Posts ObjetoCD = new CD_Posts();
        public Charts(string nombre)
        {
            InitializeComponent();
            this.user = nombre;
        }
        string user;



        private void Charts_Load(object sender, EventArgs e)
        {


            Chou();
            MessageBox.Show("Seleccione con doble click en el nombre del curso hasta que se muestre  su contenido ");
        }
        string curso = null;
        string curso2 = null;
        private void Chou()
        {
            CD_Posts ObjetoCD2 = new CD_Posts();
            dataGridView1.DataSource = ObjetoCD2.ShowCombo(user);
            this.dataGridView1.Columns["IDcursos"].Visible = false;
            this.dataGridView1.Columns["Codigo"].Visible = false;





        }
        /// <summary>
        /// funcion de graficas
        /// </summary>
        private void Dash() {
            CD_Chart neg = new CD_Chart();
            Comparar obj = new Comparar();
            neg.Dash(obj, user, curso);

            Chart1.Series[0].Points.DataBindXY(obj.Titulo1, obj.Clicks1);
        }
        private void Dash2()
        {
            CD_Chart neg2 = new CD_Chart();
            Comparar obj2 = new Comparar();
            neg2.Dash2(obj2, user, curso2);

            Chart2.Series[0].Points.DataBindXY(obj2.Titulo21, obj2.Clicks21);
        }
        /// <summary>
        /// funcion de graficas
        /// </summary>
        private void Cargar()
        {

            CD_Chart ObjetoCD3 = new CD_Chart();
            if (curso != null)
            {
                dataGridView2.DataSource = ObjetoCD3.showclicks(user, curso);
              
            }
            else
            {

                MessageBox.Show("Selecciona un Curso valido");
            }

        }



        private void VER_Click(object sender, EventArgs e)
        {
            if (curso != null)
            {
                if (Chart1.Visible == false)
                {
                    MessageBox.Show("compare ambos cursos con doble click en el nombre de otro curso  hasta que cambie la tabla de contenido y en comparar  ");
                }
                Dash();
                Chart1.Visible = true;
             
                label6.Visible = true;
                Compararbtn.Visible = true;
                curso = null;
            }
        }

        private void dataGridView1_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            curso= dataGridView1.CurrentRow.Cells["Codigo"].Value.ToString();
            
            Cargar();
        }

        private void Compararbtn_Click(object sender, EventArgs e)
        {
            curso2 = dataGridView1.CurrentRow.Cells["Codigo"].Value.ToString();
            if (curso2 != null)
            {
                
            
                label5.Visible = true;
                Dash2();
                Chart2.Visible = true;
            }
        }
    }
}
